import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tox-footerbar',
  templateUrl: './footerbar.component.html',
})
export class FooterbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
