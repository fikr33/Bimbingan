import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tox-layout-admin',
  templateUrl: './layout-admin.component.html'
})
export class LayoutAdminComponent implements OnInit {

  constructor() {
  }

  ngOnInit(): void {
  }

}
