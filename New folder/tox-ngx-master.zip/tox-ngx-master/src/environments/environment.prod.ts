export const environment = {
  production: true,
  api_url: 'https://production-api.example.com/api/v1'
};
